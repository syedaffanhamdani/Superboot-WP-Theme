<?php get_header(); ?>

	<div class="post clearfix">
		<p class="byline">
			<span class="date">Error<br />404</span>
		</p>		
		<h2 class="title">Page Not Found</h2>
		<p class="dots clear">.........................................................</p>
				
		<span class="para">&#182;</span>
		<div class="entry">
			<p>This page could not be found.</p>
		</div>
		
	</div>

<?php get_footer(); ?>